@echo off
title MatEIS - Materials Selection and Ashby Plotter
cd /d "%~dp0"
where python >nul 2>nul || (echo Python 3.10 or newer is required. Install it from python.org and tick "Add Python to PATH". & pause & exit /b)
if not exist venv\Scripts\python.exe (
  echo First-time setup, please wait. Internet is needed this one time only...
  python -m venv venv || (pause & exit /b)
  venv\Scripts\python -m pip install -q -r requirements.txt || (echo Install failed. Check your internet and run again. & rmdir /s /q venv & pause & exit /b)
)
echo Starting MatEIS... keep this window open while presenting. Close it to quit.
start "" /min cmd /c "timeout /t 4 >nul & start msedge --app=http://localhost:8501"
venv\Scripts\python -m streamlit run app.py --server.headless true --browser.gatherUsageStats false
