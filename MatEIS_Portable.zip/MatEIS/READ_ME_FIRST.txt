MatEIS - how to run (Windows)
1. Extract the whole zip (right-click > Extract All). Do not run from inside the zip.
2. Install Python 3.10+ from python.org if missing. Tick "Add Python to PATH".
3. Double-click Start_MatEIS.bat.
   First run: downloads packages (1-3 min, internet needed once).
   Next runs: starts in a few seconds, works offline.
4. The app opens in its own window. Close the black window to quit.
